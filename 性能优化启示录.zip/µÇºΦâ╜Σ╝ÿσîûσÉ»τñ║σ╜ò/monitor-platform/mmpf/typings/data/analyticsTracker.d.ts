import { IAnalyticsTrackerOptions } from '../typings/types';
declare const analyticsTracker: (options: IAnalyticsTrackerOptions) => void;
export default analyticsTracker;
//# sourceMappingURL=analyticsTracker.d.ts.map