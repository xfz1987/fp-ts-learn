import Mmpf from '../../src/mmpf';

const mmpf = new Mmpf({
  elementTiming: true,
  // 错误上报
  logUrl: 'http://123.com/test',
  // 捕获错误
  // captureError: true,
  // 页面全部资源的性能数据
  // resourceTiming: true,
});
// 模拟一个长任务
// const start = Date.now();
// // while (Date.now() - start < 1000) {}
// setTimeout(() => {
//   console.log('start', Date.now())
//   let a = Date.now()
//   while (Date.now() - start < 3000) {
//     // console.log('1')
//   }
//   console.log('end', Date.now() - a)
// },2000)
