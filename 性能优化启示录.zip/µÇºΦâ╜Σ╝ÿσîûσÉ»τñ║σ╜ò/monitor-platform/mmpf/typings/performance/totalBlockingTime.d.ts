import { IPerformanceEntry } from '../typings/types';
export declare const initTotalBlockingTime: (performanceEntries: IPerformanceEntry[]) => void;
//# sourceMappingURL=totalBlockingTime.d.ts.map