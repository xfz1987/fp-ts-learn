import { EffectiveConnectionType } from '../typings/types';
export declare const getIsLowEndDevice: () => boolean;
export declare const getIsLowEndExperience: (et: EffectiveConnectionType, sd: boolean) => boolean;
//# sourceMappingURL=isLowEnd.d.ts.map