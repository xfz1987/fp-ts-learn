import { W } from "../data/constants";

export const roundByTwo = (num: number) => {
  return parseFloat(num.toFixed(2));
};

export const convertToMB = (bytes: number): number | null => {
  if (typeof bytes !== "number") {
    return null;
  }
  return roundByTwo(bytes / Math.pow(1024, 2));
};

/**
 * PushTask to requestIdleCallback
 * 高效利用每一帧进行数据的收集
 */
export const pushTask = (cb: any): void => {
  if ("requestIdleCallback" in W) {
    (W as any).requestIdleCallback(cb, { timeout: 3000 });
  } else {
    cb();
  }
};

function useTicker(s, fetchFn) {
  const [count, setCount] = useState(s || 0);
  useEffect(() => {
    fetchFn(); // 第一次运行
    const timer = setInterval(() => {
      setCount((value) => value + 1);
      if (count === s) {
        fetchFn(); // s 秒后再次运行
        // 清空时间
        setCount(0);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  return { count };
}

function myInstanceof(left, right) {
  let temp = left.__proto__;
  while (true) {
    if (temp === null) {
      return false;
    }
    if (temp === right.prototype) {
      return true;
    }
    temp = temp.__proto__;
  }
}
