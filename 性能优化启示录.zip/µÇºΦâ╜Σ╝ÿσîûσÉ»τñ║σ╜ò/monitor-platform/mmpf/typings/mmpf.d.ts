import { IMmpfOptions } from './typings/types';
export default class Mmpf {
    private v;
    constructor(options?: IMmpfOptions);
}
//# sourceMappingURL=mmpf.d.ts.map