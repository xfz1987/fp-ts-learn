const Koa = require('koa');
const Router = require('koa-router');
const render = require('koa-swig');
const co = require('co');
const fs = require('fs');
const cheerio = require('cheerio');
const { Readable } = require('stream');
const { resolve, join } = require('path');

const app = new Koa();
const router = new Router();

app.context.render = co.wrap(
	render({
		root: join(__dirname, 'views'),
		autoescape: true,
		cache: false, // srr最关键的地方，要设置缓存为true
		ext: 'html',
		writeBody: false,
	})
);

const task1 = () => {
	return new Promise((resolve, reject) => {
		setTimeout(function () {
			resolve(`<script>addHTML("part1", "我是第一次输出")</script>`);
		}, 2000);
	});
};

const task2 = () => {
	return new Promise((resolve, reject) => {
		setTimeout(function () {
			resolve(`<script>addHTML("part2", "我是第二次输出")</script>`);
		}, 2000);
	});
};

router.get('/', async (ctx, next) => {
	ctx.status = 200;
	ctx.type = 'html';

	const filename = resolve(__dirname, 'index.html');

	// response header 中 Transfer-Encoding: chunked

	// 方式一
	// const file = fs.readFileSync(filename, 'utf-8');
	// ctx.res.write(file);
	// ctx.res.end();

	// 方式二
	// function createSsrStreamPromise() {
	//   return new Promise((resolve, reject) => {
	//     const stream = fs.createReadStream(filename);
	//     stream.on('error', err => reject(err))
	//           .pipe(ctx.res);
	//   });
	// }
	// await createSsrStreamPromise();

	// 方式三
	// function createSsrStreamPromise() {
	//   return new Promise((resolve, reject) => {
	//     const stream = fs.createReadStream(filename);
	//     stream
	//       .on('data', chunk => ctx.res.write(chunk))
	//       .on('end', () => resolve())
	//       // .on('close', () => resolve())
	//       .on('error', e => reject(e));
	//   });
	// }
	// await createSsrStreamPromise();
	// ctx.res.end();

	// 方式四
	const file = fs.readFileSync(filename, 'utf-8');
	ctx.res.write(file);
	const result1 = await task1();
	ctx.res.write(result1);
	const result2 = await task2();
	ctx.res.write(result2);
	ctx.res.end();
});

router.get('/index', async (ctx, next) => {
	ctx.body = await ctx.render('index');
});

router.get('/about', async (ctx, next) => {
	ctx.status = 200;
	ctx.type = 'html';
	const result = await ctx.render('about');
	const $ = cheerio.load(result);

	if (ctx.request.header['x-pjax']) {
		// console.log('站内切')
		$('.pjaxcontext').each(function () {
			ctx.res.write($(this).html());
		});
		ctx.res.end();
	} else {
		// console.log('站外切')
		function createSsrStreamPromise() {
			return new Promise((resolve, reject) => {
				const stream = new Readable();
				stream.push(result);
				stream.push(null);
				stream
					.on('error', err => {
						reject(err);
					})
					.pipe(ctx.res);
			});
		}
		await createSsrStreamPromise();
	}
});

app.use(router.routes()).use(router.allowedMethods());

app.listen(3000);
