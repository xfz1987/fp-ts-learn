# 性能监控 SDK

1. yarn build
2. yarn run api:doc
3. yarn run api:run
4. cd dist
5. npm publish --access=public
