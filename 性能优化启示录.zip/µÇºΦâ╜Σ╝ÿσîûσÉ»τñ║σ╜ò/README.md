[TOC]

#### 1.概念

> FP: 仅有一个div根节点
>
> FCP: 包含页面的基本框架，但没有数据内容
>
> FMP: 包含页面所有元素及数据
>
> 以上3个针对的dom的三个阶段

![](/Users/xfz/mywork/learn/new-life/性能优化启示录/assets/fp.png)

![fcp](/Users/xfz/mywork/learn/new-life/性能优化启示录/assets/fcp.png)

![fmp](/Users/xfz/mywork/learn/new-life/性能优化启示录/assets/fmp.png)

> 以 Vue 为例， 在其生命周期中，mounted 对应的是 FCP，updated 对应的是 FMP



#### 2.优化手段对比

![kk](/Users/xfz/mywork/learn/new-life/性能优化启示录/assets/kk.png)



#### 3.同构

> 以 koa + bigpipe 为例
>
> 目标：落地 SSR（刷新），切换页面 CSR（站内点击）
>
> 页面全是a标签：html原生标签，所见所得

> 根据用户请求头动态渲染：模版渲染 ctx.render()  必须上 bigpipe，先输出主要的，再输出次要的
>
> index/ 点击一个a：index.js代理a链接 -> vue-router -> ajax 
>
> 同构: c/d  ->  c-d.js 组件