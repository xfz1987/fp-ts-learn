import { IMmpfData, IVitalsScore } from '../typings/types';
export declare const webVitalsScore: Record<string, number[]>;
export declare const getVitalsScore: (measureName: string, value: IMmpfData) => IVitalsScore;
//# sourceMappingURL=vitalsScore.d.ts.map