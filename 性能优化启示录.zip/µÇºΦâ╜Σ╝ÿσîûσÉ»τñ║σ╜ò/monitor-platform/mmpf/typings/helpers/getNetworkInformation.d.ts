import { EffectiveConnectionType, IMmpfNetworkInformation } from '../typings/types';
export declare let et: EffectiveConnectionType;
export declare let sd: boolean;
export declare const getNetworkInformation: () => IMmpfNetworkInformation;
//# sourceMappingURL=getNetworkInformation.d.ts.map