import { IMmpfConfig } from '../typings/types';
export declare const config: IMmpfConfig;
//# sourceMappingURL=index.d.ts.map