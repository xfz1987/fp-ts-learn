import { IPerformanceEntry } from '../typings/types';
export declare const initFirstPaint: (performanceEntries: IPerformanceEntry[]) => void;
export declare const initLargestContentfulPaint: (performanceEntries: IPerformanceEntry[]) => void;
export declare const initElementTiming: (performanceEntries: IPerformanceEntry[]) => void;
//# sourceMappingURL=paint.d.ts.map