declare class ErrorTrace {
    private errordefo;
    constructor();
    private globalError;
    private networkError;
    private promiseError;
    private iframeError;
    run(): void;
}
export default ErrorTrace;
//# sourceMappingURL=index.d.ts.map