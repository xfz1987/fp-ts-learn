/**
 * Sends the User timing measure to analyticsTracker
 */
export declare const reportPerf: (measureName: string, data: any, customProperties?: object | undefined) => void;
//# sourceMappingURL=reportPerf.d.ts.map