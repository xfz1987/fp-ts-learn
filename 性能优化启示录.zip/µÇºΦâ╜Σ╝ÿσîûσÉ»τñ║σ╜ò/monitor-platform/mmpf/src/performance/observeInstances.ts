import { IPerfObservers } from '../typings/types';
/**
 * @remarks 核心性能数据指标对象
 * @public
 */
export const perfObservers: IPerfObservers = {};
