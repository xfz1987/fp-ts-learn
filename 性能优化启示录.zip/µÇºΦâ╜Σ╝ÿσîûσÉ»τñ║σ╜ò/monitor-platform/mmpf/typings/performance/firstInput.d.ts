import { PerformanceEventTiming } from '../typings/types';
export declare const initFirstInputDelay: (performanceEntries: PerformanceEventTiming[]) => void;
//# sourceMappingURL=firstInput.d.ts.map