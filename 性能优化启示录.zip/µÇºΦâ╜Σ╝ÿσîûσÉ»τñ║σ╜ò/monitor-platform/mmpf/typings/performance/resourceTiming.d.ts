import { IPerformanceEntry } from '../typings/types';
export declare const initResourceTiming: (performanceEntries: IPerformanceEntry[]) => void;
//# sourceMappingURL=resourceTiming.d.ts.map