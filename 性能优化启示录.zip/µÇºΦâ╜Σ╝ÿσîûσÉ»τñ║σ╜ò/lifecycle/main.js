/**
 * 生命周期状态：
 * active	网页可见，且具有焦点
 * passive	网页可见，但处于失焦状态
 * hidden	网页不可见，但未被浏览器冻结，一般由用户切换到别的 tab 或最小化浏览器触发
 * frozen	网页被浏览器冻结（一些后台任务例如定时器、fetch 等被挂起以节约 CPU 资源）
 * terminated	网页被浏览器卸载并从内存中清理。一般用户主动将网页关闭时触发此状态
 * discarded	网页被浏览器强制清理。一般由系统资源严重不足引起
 * 
 * 可见状态：active passive
 * 不可见状态：hidden terminated frozen discarded
 * 
 * 监听事件
 * focus: DOM 元素已获得焦点
 * blur: DOM 元素失去焦点
 * visibilitychange: 有三个值：visible、hidden、prerender(页面此时正在渲染中，因此是不可见的),document.visibilityState
 * freeze: 该页面刚刚被冻结
 * resume: 浏览器已恢复冻结的页面
 * pageshow: boolean
 * pagehide
 * beforeunload
 * unload
 */

const getState = () => {
  if (document.visibilityState === 'hidden') {
    return 'hidden';
  }
  if (document.hasFocus()) {
    return 'active';
  }
  return 'passive';
};

let state = getState();

console.log('开始：', state)

const logStateChange = (nextState) => {
  const prevState = state;
  if (nextState !== prevState) {
    console.log(`State change: ${prevState} >>> ${nextState}`);
    state = nextState;
  }
};

// Options used for all event listeners.
const opts = { capture: true };

window.addEventListener('pageshow', e => {
  console.log('111', e)
})


// ['pageshow', 'focus', 'blur', 'visibilitychange', 'resume'].forEach(type => {
//   window.addEventListener(type, e => {
//     console.log(e); // e.type: pageshow, focus, blur, visibilitychange, resume
//     logStateChange(getState(), opts)
//   });
// });

// chrome://discards
window.addEventListener('freeze', () => {
  // In the freeze event, the next state is always frozen.
  logStateChange('frozen');
}, opts);

// 确定页面在隐藏选项卡中是否被丢弃，丢弃的页面必须重新加载才能再次使用
if (document.wasDiscarded) {
  // Page was previously discarded by the browser while in a hidden tab.
  console.log('----- discarded -----')
}

// pagehide 可能是冻结或卸载
window.addEventListener('pagehide', (event) => {
  logStateChange(event.persisted ? 'frozen' : 'terminated');
}, opts);

// 建议始终使用pagehide事件来检测可能的页面卸载，unload在移动端不可靠
const terminationEvent = 'onpagehide' in self ? 'pagehide' : 'unload';

// beforeunload但使用它会阻止页面添加到后退/前进缓存中，因此建议您仅beforeunload在用户有未保存的更改时添加侦听器，然后在保存未保存的更改后立即删除它们
// addEventListener('beforeunload', (event) => {
//   // A function that returns `true` if the page has unsaved changes.
//   if (pageHasUnsavedChanges()) {
//     event.preventDefault();
//     return (event.returnValue = 'Are you sure you want to exit?');
//   }
// });

// 应该使用下面的方式
const beforeUnloadListener = (event) => {
  event.preventDefault();
  return (event.returnValue = 'Are you sure you want to exit?');
};

// A function that invokes a callback when the page has unsaved changes.
// onPageHasUnsavedChanges(() => {
//   addEventListener('beforeunload', beforeUnloadListener);
// });

// // A function that invokes a callback when the page's unsaved changes are resolved.
// onAllChangesSaved(() => {
//   removeEventListener('beforeunload', beforeUnloadListener);
// });

