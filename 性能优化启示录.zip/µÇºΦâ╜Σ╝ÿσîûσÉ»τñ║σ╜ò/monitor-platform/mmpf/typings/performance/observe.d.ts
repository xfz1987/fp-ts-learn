export declare const initPerformanceObserver: () => void;
export declare const disconnectPerfObserversHidden: () => void;
//# sourceMappingURL=observe.d.ts.map