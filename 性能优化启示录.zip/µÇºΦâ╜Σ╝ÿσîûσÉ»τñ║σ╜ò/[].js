[].reduce((acc, curr, index, this) => {}, [])

Array.prototype.reduce = function (callback, initial) {
  let acc = initial !== undefined ? initial : this[0];
  let i = initial !== undefined ? 0 : 1;
  for (i; i < this.length; i++) {
    acc = callback(acc, this[i], i, this);
  }
  return acc;
}  

const p = new Promise((resolve, reject) => {
  console.log(1111);
});

function MyPromise(callback) {
  this.status = 'pending';
  this.result = null;
  this.reason = null;

  let resolve = data => {
    if (this.status === 'pending') {
      this.status = 'fulfilled';
      this.result = data;
    }
  }

  let reject = e => {
    if (this.status === 'pending') {
      this.status = 'rejected';
      this.reason = e;
    }
  }

  try {
    callback(resolve, reject);
  } catch (e) {
    reject(e)
  }
}

MyPromise.prototype.then = function(onFulfilled, onRejected) {
  if (this.state === 'fulfilled') {
    onFulfilled(this.value);
  } else if (this.state === 'rejected') {
    onRejected(this.reason);
  }
}

MyPromise.prototype.catch = function (onReject) {
  onReject(this.reason)
}

function promiseAll(promises) {
  return new Promise((resolve, reject) => {
    if (!Array.isArray(promises)) {
      return reject(new TypeError('Arguments must be an array'));
    }
    let count = 0;
    let len = promises.length;
    let result = new Array(len);
    for (let i = 0; i < len; i++) {
      Promise.resolve(promises[i]).then(value => {
        result[i] = value;
        count++;
        if (count === len) {
          return resolve(result);
        }
      }, reason => {
        return reject(reason)
      });
    }
  })
}

function promiseRace(promises) {
  return new Promise((resolve, reject) => {
    if (!Array.isArray(promises)) {
      return reject(new TypeError('Arguments must be an array'));
    }
    for (let i = 0; i < promises.length; i++) {
      Promise.resolve(promises[i]).then(resolve, reject);
    }
  });
}

// 使用示例
let promise1 = new Promise((resolve, reject) => setTimeout(resolve, 500, 'one'));
let promise2 = new Promise((resolve, reject) => setTimeout(resolve, 100, 'two'));

promiseRace([promise1, promise2]).then(value => {
    console.log(value); // "two" - 因为promise2更快解决
});


function promiseAllSettled(promises) {
  return new Promise((resolve, reject) => {
    if (!Array.isArray(promises)) {
      return reject(new TypeError('Arguments must be an array'));
    }
    let count = 0;
    let len = promises.length;
    let result = new Array(len);

    promises.forEach((p, index) => {
      Promise.resolve(p).then(value => {
        result[index] = { status: 'fulfilled', value };
      }, reason => {
        result[index] = { status: 'rejected', reason };
      }).finally(() => {
        count++;
        if (count === len) {
          resolve(result)
        }
      })
    });
  })
}

// 使用示例
let promise1 = Promise.resolve(3);
let promise2 = new Promise((resolve, reject) => setTimeout(reject, 100, 'error'));
let promise3 = 42;

promiseAllSettled([promise1, promise2, promise3]).then(values => {
  console.log(values); // [{status: "fulfilled", value: 3}, {status: "rejected", reason: "error"}, {status: "fulfilled", value: 42}]
});